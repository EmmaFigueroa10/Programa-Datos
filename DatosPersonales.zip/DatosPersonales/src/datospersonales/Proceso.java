//Crear, Modificar, Eliminar
package datospersonales;

import java.util.ArrayList;

public class Proceso {
   private ArrayList<Object> a = new ArrayList<Object>();
//constructor vacio
public Proceso(){
} 
public Proceso(ArrayList<Object> a){
        this.a = a;
    }
    
//crear un nuevo registro en un archivo plano
public void crearRegistro(DatosPersonales p){
        this.a.add(p);
    }
//modificarRegistro
public void modificarRegistro(int i, DatosPersonales p){
        this.a.set(i, p);
    }
//Eliminar Registros
public void eliminarRegistros(int i){
        this.a.remove(i); 
    }
//Recorrido y obtener los Datos Personales
 public DatosPersonales obtenerRegistro(int i){
        return (DatosPersonales)a.get(i);
    }
//crear una clase que determine la cantidad de registros encontradods
 public int cantidadRegistros(){
        return this.a.size();
    }
//Crear un Buscador 
public int buscarCodigo(int TELEFONO){
        for(int i = 0; i < cantidadRegistros(); i++){
            if(TELEFONO == obtenerRegistro(i).getTELEFONO())return i;
        }
        return -1;
    }
}