//Atributos de los datos personales
package datospersonales;

public class DatosPersonales {
    private int TELEFONO;
    private String NOMBRES;
    private String APELLIDOS;
    private String DIRECCION;
    private int DPI;
    private int EDAD;
    private int SEXO;
    
    
    //crear un constructor vacio
    public DatosPersonales(){
    }
//Creacion de un constuctor
    public DatosPersonales(int TELEFONO, String NOMBRES, String APELLIDOS,String DIRECCION,int DPI, int EDAD, int SEXO  ) {
        this.TELEFONO = TELEFONO;
        this.NOMBRES = NOMBRES;
        this.APELLIDOS = APELLIDOS;
        this.DIRECCION = DIRECCION;
        this.DPI = DPI;
        this.EDAD = EDAD;
        this.SEXO = SEXO;
       
    }
   //Set y Get

    public int getTELEFONO() {
        return TELEFONO;
    }

    public void setTELEFONO(int codigo) {
        this.TELEFONO = TELEFONO;
    }

    public String getNOMBRES() {
        return NOMBRES;
    }

    public void setNOMBRES(String nombre) {
        this.NOMBRES = NOMBRES;
    }

    public String getAPELLIDOS() {
        return APELLIDOS;
    }

    public void setAPELLIDOS(String apellidos) {
        this.APELLIDOS = APELLIDOS;
    }

    public String getDIRECCION() {
        return DIRECCION;
    }

    public void setDIRECCION(String DIRECCION) {
        this.DIRECCION = DIRECCION;
    }
    
    
     public int getDPI() {
        return DPI;
    }

    public void setDPI(int DPI) {
        this.DPI = DPI;
     
    }
        
     public int getEDAD() {
        return EDAD;
    }

    public void setEDAD(int EDAD) {
        this.EDAD = EDAD;
        
    } 
         public int getSEXO() {
        return SEXO;
    }

    public void setSEXO(int SEXO) {
        this.SEXO = SEXO;
    
    
    
    }
}
